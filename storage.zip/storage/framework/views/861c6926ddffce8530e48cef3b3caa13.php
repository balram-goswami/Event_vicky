<div class="container-fluid py-2">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $Event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <img src="<?php echo e(asset('storage/event_images/' . $event->image_path)); ?>"
                        class="card-img-top"
                        alt="Event Image"
                        style="padding: 12px; border-radius: 18px;">
                    <div class="card-body text-center">
                        <h5 class="card-title">
                            <?php echo e($event->event_name); ?> <span class="text-highlight"><?php echo e($event->guest_names); ?></span>
                            PROGRAM <?php echo e($event->event_date); ?><br>
                            Speaker <?php echo e($event->speaker_name); ?><br>
                            Event Type <?php echo e($event->event_type); ?>

                        </h5>
                        <p class="card-text"><?php echo e($event->description); ?></p>
                    </div>

                    
                    <?php
                    $paymentHistoryForEvent = $PaymentHistory->where('event_id', $event->id)->first();
                    ?>

                    <?php if($paymentHistoryForEvent && $paymentHistoryForEvent->status == 2): ?>
                    <div class="card-footer text-center">
                        <a href="<?php echo e(route('eventtraning', ['id' => $event->id])); ?>">
                            <button class="btn btn-primary" data-event-id="<?php echo e($event->id); ?>">Start Learning</button>
                        </a>

                    </div>
                    <?php else: ?>
                    <div class="card-footer text-center">
                        <button class="btn btn-primary pay-now-btn" data-event-id="<?php echo e($event->id); ?>">Pay Now</button>
                        <button class="btn btn-secondary pay-crypto-btn" data-event-id="<?php echo e($event->id); ?>">Pay With Crypto</button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <!-- Pay Now Modal -->
            <div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Make a Payment</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('PaymentHistory.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="eventId" name="event_id">
                                <input type="hidden" id="payment_method" name="payment_method"> <!-- Hidden field for payment method -->
                                <div class="form-group">
                                    <label for="amount">Amount</label>
                                    <div class="input-group input-group-outline">
                                        <input type="number" class="form-control" id="amount" name="amount" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="transactionId">Transaction ID</label>
                                    <div class="input-group input-group-outline">
                                        <input type="text" class="form-control" id="transactionId" name="transaction_id" required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary" id="submitPayment">Submit</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                            </form>

                        </div>

                    </div>
                </div>
            </div>

            <!-- Pay With Crypto Modal -->
            <div class="modal fade" id="cryptoPaymentModal" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Pay With Crypto</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('PaymentHistory.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <!-- Hidden Fields -->
                                <input type="hidden" id="cryptoEventId" name="event_id">
                                <input type="hidden" id="payment_method" name="payment_method" value="2">

                                <div class="form-group">
                                    <label for="amount">Amount</label>
                                    <div class="input-group input-group-outline">
                                        <input type="number" class="form-control" id="amount" name="amount" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="transactionId">Transaction ID</label>
                                    <div class="input-group input-group-outline">
                                        <input type="text" class="form-control" id="transactionId" name="transaction_id" required>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-secondary">Pay With Crypto</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<script>
    // Ensure DOM is fully loaded
    document.addEventListener('DOMContentLoaded', () => {
        // Handle Pay Now button clicks
        document.querySelectorAll('.pay-now-btn').forEach(button => {
            button.addEventListener('click', function() {
                const eventId = this.getAttribute('data-event-id');
                document.getElementById('eventId').value = eventId; // Set event ID in hidden input
                document.getElementById('payment_method').value = 1; // Set payment method to '1' for Pay Now
                $('#paymentModal').modal('show'); // Show the modal
            });
        });

        document.querySelectorAll('.pay-crypto-btn').forEach(button => {
            button.addEventListener('click', function() {
                const eventId = this.getAttribute('data-event-id');
                document.getElementById('cryptoEventId').value = eventId; // Set event ID in hidden input
                document.getElementById('payment_method').value = 2; // Ensure method value is set
                $('#cryptoPaymentModal').modal('show'); // Show the modal
            });
        });

    });
</script><?php /**PATH C:\xampp\htdocs\Crypque_Eventy\resources\views/UserPanel/coures_payment_pages.blade.php ENDPATH**/ ?>