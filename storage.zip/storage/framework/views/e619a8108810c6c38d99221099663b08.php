<style>
    /* Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }

    th,
    td {
        padding: 12px;
        text-align: left;
        border: 1px solid #ddd;
    }

    /* Styling for table header */
    th {
        background-color: #4CAF50;
        color: white;
    }

    /* Alternate row colors using nth-child */
    tr:nth-child(even) {
        background-color: #f2f2f2;
        /* Light gray for even rows */
    }

    tr:nth-child(odd) {
        background-color: #ffffff;
        /* White for odd rows */
    }
</style>
<!-- End Navbar -->
<div class="container-fluid py-2">
    <div class="card">
        <div class="card-body">
            <div class="container mt-4">
                <h3 class="mb-4">Pending Payment Approvals</h3>


                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User name</th>
                                <th>Event name</th>
                                <th>Amount</th>
                                <th>Transaction</th>
                                <th>Type</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $PaymentPending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($history->user->name); ?></td>
                                <td><?php echo e($history->UserEvent->event_name); ?></td>
                                <td><?php echo e($history->amount); ?></td>
                                <td><?php echo e($history->transaction_id); ?></td>
                                <td><?php echo e($history->type ? 'Pay now' : 'Pay with crypto'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($history->payment_date)->format('d/m/Y')); ?></td>
                                <td>Pending</td>
                                <td>
                                    <!-- Accept Button -->
                                    <form action="<?php echo e(route('payment-history.accept', $history->id)); ?>" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-warning btn-sm">Approved</button>
                                    </form>

                                    <!-- Reject Button -->
                                    <form action="<?php echo e(route('payment-history.reject', $history->id)); ?>" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                    </form>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center">
                    <?php echo e($PaymentPending->links()); ?> <!-- Pagination Links -->
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-2">
    <div class="card">
        <div class="card-body">
            <div class="container mt-4">
                <h3 class="mb-4">Approved Payments</h3>


                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User name</th>
                                <th>Event name</th>
                                <th>Amount</th>
                                <th>Transaction</th>
                                <th>Type</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $PaymentComplete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($history->user->name); ?></td>
                                <td><?php echo e($history->UserEvent->event_name); ?></td>
                                <td><?php echo e($history->amount); ?></td>
                                <td><?php echo e($history->transaction_id); ?></td>
                                <td><?php echo e($history->type ? 'Pay now' : 'Pay with crypto'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($history->payment_date)->format('d/m/Y')); ?></td>
                                <td>Approved</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center">
                    <?php echo e($PaymentComplete->links()); ?> <!-- Pagination Links -->
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Crypque_Eventy\resources\views/AdminPenal/payment_his.blade.php ENDPATH**/ ?>