<style>
    /* General Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        font-size: 16px;
        font-family: Arial, sans-serif;
        background-color: #ffffff;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    th,
    td {
        padding: 14px 20px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    /* Header Styling */
    th {
        background-color: #4CAF50;
        color: white;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: bold;
    }

    /* Row Styling */
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }



    /* Responsive Table */
    @media (max-width: 768px) {
        table {
            font-size: 14px;
        }

        th,
        td {
            padding: 10px;
        }
    }
</style>


<div class="container-fluid py-2">
    <div class="card">
        <div class="card-body">
            <div class="container mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="fw-bold py-3 mb-0 pull-left">List Of Event By Users</h4>
                </div>

                <!-- Success Message -->
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <!-- Error Message -->
                <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>

                <!-- Event Types Table -->
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User Name</th>
                            <th>Event Name</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->id); ?></td>
                            <td><?php echo e($userName); ?></td>
                            <td><?php echo e($data->event_name); ?></td>
                            <?php if($data->status === 1): ?>
                            <td style="color: #007BFF;">Pending</td>
                            <?php elseif($data->status === 2): ?>
                            <td style="color: #4CAF50;">Approved</td>
                            <?php else: ?>
                            <td style="color: #b02a37;">Rejected</td>
                            <?php endif; ?>
                            <td>
                                <?php if($data->status === 2): ?>
                                <a href="<?php echo e(route('admin.publishedEventReview', $data->id)); ?>" class="btn btn-danger">View</a>
                                <form action="<?php echo e(route('admin.publishEventDelete', $data->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this event?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                                <?php else: ?>
                                <a href="<?php echo e(route('admin.publishedEventReview', $data->id)); ?>" class="btn btn-danger">View</a>
                                <form action="<?php echo e(route('publishEventStatusUpdate', $data->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="status" value="2">
                                    <button type="submit" class="btn btn-success">Approve</button>
                                </form>
                                <form action="<?php echo e(route('publishEventStatusUpdate', $data->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to Reject this event?');">
                                    <?php echo csrf_field(); ?>
                                    <input name="status" value="3" hidden>
                                    <button type="submit" class="btn btn-warning">Reject</button>
                                </form>
                                <form action="<?php echo e(route('admin.publishEventDelete', $data->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this event?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                                <?php endif; ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</main><?php /**PATH C:\xampp\htdocs\Crypque_Eventy\resources\views/AdminPenal/PublishRequestView.blade.php ENDPATH**/ ?>