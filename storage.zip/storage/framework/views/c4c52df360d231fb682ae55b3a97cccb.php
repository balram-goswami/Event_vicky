<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(publicPath('/assets/img/apple-icon.png')); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(publicPath('/assets/img/favicon.png')); ?>">
  <title>
    Crypque Events Login Form
  </title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700,900" />
  <!-- Nucleo Icons -->
  <link href="<?php echo e(publicPath('/assets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(publicPath('/assets/css/nucleo-svg.css')); ?>" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <!-- Material Icons -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
  <!-- CSS Files -->
  <link id="pagestyle" href="<?php echo e(publicPath('/assets/css/material-dashboard.css?v=3.2.0')); ?>" rel="stylesheet" />
</head>

<body class="">

  <main class="main-content  mt-0">
    <section>
      <div class="page-header min-vh-100">
        <div class="container">
          <div class="row">
            <div class="col-6 d-lg-flex d-none h-100 my-auto pe-0 position-absolute top-0 start-0 text-center justify-content-center flex-column">
              <div class="position-relative bg-gradient-primary h-100 m-3 px-7 border-radius-lg d-flex flex-column justify-content-center"
                style="background-image: url('../assets/img/illustrations/illustration-signup.jpg'); background-size: cover;">
              </div>
            </div>
            <div class="col-xl-4 col-lg-5 col-md-7 d-flex flex-column ms-auto me-auto ms-lg-auto me-lg-5">
              <div class="card card-plain">
                <div class="card-header">
                  <h4 class="font-weight-bolder" style="display: flex;
                     justify-content: center;">Welcome Back</h4>
                  <p class="mb-0" style="display: flex;
                       justify-content: center;">Login into your account</p>
                </div>
                <div class="card-body">

                  <!-- Display Errors -->
                  <?php if($errors->any()): ?>
                  <div class="alert alert-danger" id="error-alert">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <?php endif; ?>

                  <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <!-- Email Input -->
                    <div class="input-group input-group-outline mb-3">
                      <label class="form-label">Enter Email</label>
                      <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                      <?php if($errors->has('email')): ?>
                      <div class="alert alert-danger mt-1"><?php echo e($errors->first('email')); ?></div>
                      <?php endif; ?>
                    </div>

                    <!-- Password Input -->
                    <div class="input-group input-group-outline mb-3">
                      <label class="form-label">Password</label>
                      <input type="password" class="form-control" name="password" required>
                      <?php if($errors->has('password')): ?>
                      <div class="alert alert-danger mt-1"><?php echo e($errors->first('password')); ?></div>
                      <?php endif; ?>
                    </div>

                    <!-- Submit Button -->
                    <div class="text-center">
                      <button type="submit" class="btn btn-lg bg-gradient-dark btn-lg w-100 mt-4 mb-0">Log In</button>
                    </div>
                  </form>



                </div>
                <div class="card-footer text-center pt-0 px-lg-2 px-1">
                  <p class="mb-2 text-sm mx-auto">
                    Don't have an account?
                    <a href="<?php echo e(route('register')); ?>" class="text-primary text-gradient font-weight-bold">Sign Up</a>
                  </p>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>
    </section>
  </main>
  <!--   Core JS Files   -->
  <script src="<?php echo e(publicPath('/assets/js/core/popper.min.js')); ?>"></script>
  <script src="<?php echo e(publicPath('/assets/js/core/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(publicPath('/assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(publicPath('/assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo e(publicPath('/assets/js/material-dashboard.min.js?v=3.2.0')); ?>"></script>
</body>

</html>
<script>
  // Set a timeout to remove the alert after 120 seconds (120000 milliseconds)
  setTimeout(function() {
    var errorAlert = document.getElementById('error-alert');
    if (errorAlert) {
      errorAlert.style.display = 'none';
    }
  }, 120); // 120 seconds
</script><?php /**PATH C:\xampp\htdocs\Crypque_Eventy\resources\views/UserPanel/login.blade.php ENDPATH**/ ?>