<script src="<?php echo e(publicPath('/assets/js/core/popper.min.js')); ?>"></script>
<script src="<?php echo e(publicPath('/assets/js/core/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(publicPath('/assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(publicPath('/assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(publicPath('/assets/js/plugins/chartjs.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\Crypque_Eventy\resources\views/Layout/Script.blade.php ENDPATH**/ ?>