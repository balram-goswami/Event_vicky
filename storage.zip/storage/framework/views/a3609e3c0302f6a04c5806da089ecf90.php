<div class="container-fluid py-2">
    <style>
        .dashboardbox {
            height: 192px;
            background: #00bcd491;
            border-radius: 9px;
            display: flex;
            align-items: center;
            margin-bottom: auto;
        }

        .fontsize {
            font-size: 12px;
        }
    </style>
    <h3>Events By Admin</h3>
    <div class="row g-1">
        <?php $__currentLoopData = $adminEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-6">
            <div class="card" style="min-height: 223px;">
                <div class="card-body">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-md-6 custom-card">
                                <h4 class="fontsize"><?php echo e($data->event_name); ?></h4>
                                <p class="description fontsize"><?php echo e($data->description); ?></p>
                                <h4 class="fontsize">Event By:- <?php echo e($data->user->name); ?></h4>
                                <h4 class="fontsize">Event Type:- <?php echo e($data->eventType->name); ?></h4>
                                <a href="<?php echo e(route('courespaymentpage', $data->id)); ?>">
                                    <button class="btn join-btn">Join Event</button>
                                </a>
                            </div>
                            <div class="col-md-6">
                                <div class="program-card">
                                    <img src="<?php echo e(asset('storage/event_images/' . $data->image_path)); ?>"
                                        class="card-img-top"
                                        alt="Event Image"
                                        style="padding: 12px; border-radius: 18px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br>
    <h3>Event I Created</h3>
    <div class="row g-1">
        <?php $__currentLoopData = $userEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-6">
            <div class="card" style="min-height: 223px;">
                <div class="card-body">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-md-6 custom-card">
                                <h4 class="fontsize"><?php echo e($data->event_name); ?></h4>
                                <p class="description fontsize"><?php echo e($data->description); ?></p>
                                <h4 class="fontsize">Event By:- <?php echo e($data->user->name); ?></h4>
                                <h4 class="fontsize">Event Type:- <?php echo e($data->eventType->name); ?></h4>
                                <a href="">
                                    <button class="btn join-btn">Share Event</button>
                                </a>
                            </div>
                            <div class="col-md-6">
                                <div class="program-card">
                                    <img src="<?php echo e(asset('storage/event_images/' . $data->image_path)); ?>"
                                        class="card-img-top"
                                        alt="Event Image"
                                        style="padding: 12px; border-radius: 18px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div><?php /**PATH C:\xampp\htdocs\Crypque_Eventy\resources\views/UserPenal/dashboard.blade.php ENDPATH**/ ?>