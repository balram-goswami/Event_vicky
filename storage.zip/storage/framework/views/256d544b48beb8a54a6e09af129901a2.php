<style>
    .create-event-card {
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 150px auto;
    }

    .plus-icon {
        font-size: 40px;
        color: #000;
    }

    .create-event-text {
        font-size: 16px;
        font-weight: bold;
        margin-top: 10px;
    }

    .highlight {
        color: #28c;
    }
</style>
<style>
    /* Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }

    th,
    td {
        padding: 12px;
        text-align: left;
        border: 1px solid #ddd;
    }

    /* Styling for table header */
    th {
        background-color: #4CAF50;
        color: white;
    }

    /* Alternate row colors using nth-child */
    tr:nth-child(even) {
        background-color: #f2f2f2;
        /* Light gray for even rows */
    }

    tr:nth-child(odd) {
        background-color: #ffffff;
        /* White for odd rows */
    }
</style>

<div class="container-fluid py-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-6 mb-4">
                <div class="card h-100">
                    <img src="<?php echo e(asset('storage/event_images/' . $eventDetail->image_path)); ?>"
                        class="card-img-top"
                        alt="Event Image"
                        height="200px"
                        width="100%"
                        style="padding: 12px; border-radius: 18px;">
                    <div class="card-body row">
                        <h5 class="card-title col-lg-6">
                            <?php echo e($eventDetail->event_name); ?> <br>
                            Guest :- <?php echo e($eventDetail->guest_names); ?><br>
                            PROGRAM :- <?php echo e($eventDetail->event_date); ?><br>
                            Speaker :- <?php echo e($eventDetail->speaker_name); ?><br>
                        </h5>
                        <p class="card-text"><?php echo e($eventDetail->description); ?></p>
                    </div>
                    
                    <a class="btn btn-primary" href="<?php echo e(route('shareEvent', $eventDetail->id)); ?>">Share Event</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid py-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <h5 class="card-title">Leads</h5>
                        <table>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Crypque_Eventy\resources\views/UserPanel/userevents/ViewEventDetails.blade.php ENDPATH**/ ?>