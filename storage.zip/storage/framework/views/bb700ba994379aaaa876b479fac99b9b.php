<nav class="navbar navbar-main navbar-expand-lg px-0 mx-3 shadow-none border-radius-xl" id="navbarBlur"
      data-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Keep Learning </a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page" id="breadcrumb-page-name">
              <!-- Page name will go here -->
            </li>
          </ol>
        </nav>
       
      </div>
    </nav>
   
   <?php /**PATH C:\xampp\htdocs\Crypque_Eventy\resources\views/traning_header/head.blade.php ENDPATH**/ ?>